class Aufgabe_2 {

    public static void main(String[] args) {
        int i, j = 0;
        for (i = 0; i < 3; i++)
            System.out.println(i);
        while (j < 3) {
            System.out.println(j);
            j++;
        }
    }
}